PitTech cook archive, schema 8. Cook records are stored in data/pittech.json. This archive can be imported by PitTech on iOS or Android.
