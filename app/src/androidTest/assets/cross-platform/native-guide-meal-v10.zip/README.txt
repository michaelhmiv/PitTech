PitTech cook archive, schema 10. Cook records, editable sharing drafts and saved collections are stored in data/pittech.json. This archive can be imported by PitTech on iOS or Android.
